package com.example.foodappnavigation

interface Destinations {
    var route : String
}

object Login : Destinations {
    override var route: String = "login"
}

object Cart : Destinations {
    override var route: String = "cart"
    const val argUserName : String = "userName"
}

object Checkout : Destinations {
    override var route: String = "checkout"
    const val argUserName : String = "userName"
    const val argBill : String = "bill"
}