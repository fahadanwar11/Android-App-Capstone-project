package com.example.foodappnavigation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.material.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Item(item: String, updateBill: (Int)->Unit){
    var bill = rememberSaveable { mutableStateOf(0) }

    Card(
        elevation = 16.dp,
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
    ){
        Row(
            modifier = Modifier.fillMaxWidth(0.75f),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { updateBill(-1) }) {
                Text(
                    text = "-",
                    fontSize = 36.sp
                )
            }
            Text(
                text = item,
                fontSize = 48.sp
            )
            TextButton(onClick = { updateBill(+1) }) {
                Text(
                    text = "+",
                    fontSize = 36.sp
                )
            }
        }
    }
}