package com.example.foodappnavigation

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@Preview(showBackground = true)
@Composable
fun Cart(userName:String, navController: NavHostController) {
    var bill = remember { mutableStateOf(0) }

    Column {
        Row(
            modifier = Modifier
                .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ){
            Text(
                text = "Hello Mr. ${userName}",
                fontSize = 25.sp,
                modifier = Modifier.padding(vertical = 20.dp),
            )
        }

        Row(
            modifier = Modifier
                .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ){
            Text(
                text = "Cart",
                fontSize = 55.sp,
                modifier = Modifier.padding(vertical = 20.dp),
                // make text bold
                style = TextStyle(fontWeight = FontWeight.Bold)
            )
        }

        Item(item = "Burger") {
            bill.value += it*5
            if(bill.value < 0)
                bill.value = 0
        }
        Item(item = "Fries") {
            bill.value += it*3
            if(bill.value < 0)
                bill.value = 0
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 20.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Total: ${bill.value}",
                fontSize = 50.sp
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 20.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(onClick = {
                    navController.navigate(Checkout.route + "/${userName}/${bill.value}")
            }
            ) {
                Text(text = "Checkout")
            }
        }
    }

}