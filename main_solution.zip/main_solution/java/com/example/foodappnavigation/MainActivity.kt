package com.example.foodappnavigation

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.magnifier
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    @SuppressLint("UnusedMaterialScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text("My App")
                        },
                    )
                },
                content = { innerPadding ->
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        MyNavigation()
                    }
                }
            )
        }
    }
}

@Composable
fun MyNavigation(){
    var navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = Login.route
    ){
        composable(Login.route){
            Login(navController)
        }
        composable(
            Cart.route + "/{${Cart.argUserName}}",
            arguments = listOf(
                navArgument(Cart.argUserName){
                    type = NavType.StringType
                }
            )
        ){
            val username = it.arguments?.getString(Cart.argUserName) ?: ""
            Cart(username, navController)
        }
        composable(
            Checkout.route + "/{${Checkout.argUserName}}/{${Checkout.argBill}}",
            arguments = listOf(
                navArgument(Checkout.argUserName){
                    type = NavType.StringType
                },
                navArgument(Checkout.argBill){
                    type = NavType.IntType
                }
            )
        ){
            var user = it.arguments?.getString(Checkout.argUserName) ?: ""
            var bill = it.arguments?.getInt(Checkout.argBill) ?: 0
            Checkout(user, bill)
        }
    }
}
