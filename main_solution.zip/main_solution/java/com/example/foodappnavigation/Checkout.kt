package com.example.foodappnavigation

import androidx.compose.foundation.layout.*
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun RowText(text: String, fontSize:Int){
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 20.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            fontSize = fontSize.sp,
            )
    }

}

@Preview(showBackground = true)
@Composable
fun Checkout(userName:String, bill:Int){
    Card(
        elevation = 16.dp,
        modifier = Modifier.wrapContentSize()
    ){
        Column(

        ) {
            RowText("Thank you", 50)
            RowText("Mr. $userName", 30)
            RowText("Your total is:", 20)
            RowText("Rs. $bill", 50)

        }

    }
}