package com.example.foodappnavigation

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@Preview(showBackground = true)
@Composable
fun Login(navController: NavHostController) {
    var user = rememberSaveable { mutableStateOf("") }
    var pass = rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current

    Card(
        elevation = 16.dp,
        modifier = Modifier.wrapContentSize()
    ){
        Column(

        ) {

            Text(
                text="Username:",
                fontSize = 18.sp,
                modifier = Modifier.padding(start=16.dp, end = 16.dp, bottom = 10.dp)
            )
            TextField(
                value = "${user.value}",
                onValueChange = { user.value = it },
                modifier = Modifier.padding(start=16.dp, end = 16.dp, bottom = 10.dp)
            )
            Text(
                text="Password:",
                fontSize = 18.sp,
                modifier = Modifier.padding(start=16.dp, end = 16.dp, bottom = 10.dp)
            )
            TextField(
                value = "${pass.value}",
                onValueChange = { pass.value = it },
                modifier = Modifier.padding(start=16.dp, end = 16.dp, bottom = 10.dp)
            )
            Button(
                onClick = {
                    if(user.value == "admin" && pass.value == "admin")
                        //Toast.makeText(context, "Login Successful", Toast.LENGTH_SHORT).show()
                        navController.navigate(Cart.route + "/${user.value}")
                    else
                        Toast.makeText(context, "Login Failed", Toast.LENGTH_SHORT).show()

                },
                modifier = Modifier.padding(start=16.dp, end = 16.dp, bottom = 10.dp)
            ) {
                Text(text = "Login")
            }
        }
    }
}